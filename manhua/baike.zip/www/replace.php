<?php
!defined('GODHOUSE_INIT') && exit;

$pages = array(
	'ziran','wenhua','dili','lishi','shenghuo', 'shehui','yishu','renwu','jingji','kexue','tiyu'
);
if(in_array($pageType, $pages)) {
	//echo $pageType;
	$pageType = 'nav';
}
switch($pageType) {
	case 'index':
		$tmpInfo = preg_replace('/<title>.*?<\/title>/is', '<title>new title</title>', $tmpInfo);
		/* �滻��¼ */
		$tmpInfo = preg_replace("/<div id=\"usrbarWrap\">(.*)<\/form>\r\n<\/div>/isU", '', $tmpInfo);
		/* �滻ͷ�� */
		$tmpInfo = preg_replace("/<div id=\"header\">(.*)	<\/div>/isU", '', $tmpInfo);
		/* �ײ����� */
		$tmpInfo = preg_replace("/<div id='rights' class=\"area\">(.*)<\/div>/isU", '', $tmpInfo);
		break;
	case 'view':
		$tmpInfo = preg_replace("/<div id=\"search\">(.*)<div class=\"nslog-area\" data-nslog-type=\"1000\" id=\"path\">/isU", '<div class="nslog-area" data-nslog-type="1000" id="path">', $tmpInfo);
		$tmpInfo = preg_replace("/<div id=\"usrbar\">(.*)<\/div>/isU", '', $tmpInfo);
		$tmpInfo = preg_replace("/<div class=\"col-sub\" id=\"side\">(.*)<\/div><img src=/isU", '</div><img src=', $tmpInfo);
		break;
	case 'nav':
		$tmpInfo = preg_replace("/<div id=\"usrbar\">(.*)<style>\r\n\.popb2/isU", "<style>\r\n.popb2", $tmpInfo);
		$tmpInfo = preg_replace("/<div id=\"search\">(.*)<ul class=\"nav f14 clearfix\">/isU", '<ul class="nav f14 clearfix">', $tmpInfo);
		/* ���� */
		$tmpInfo = preg_replace("/<div id=\"col2\">(.*)<div id=\"ft\">/is", '<div id="ft">', $tmpInfo);
		break;
}
/*-----����-------*/
/* ������Ĳ˵� */
$tmpInfo = preg_replace("/����<\/a><\/li>(.*)<style type=\"text\/css\" compress>/isU", '����</a></li><style type="text/css" compress>', $tmpInfo);
/* �ײ� */
$tmpInfo = preg_replace("/<div id=\"ft\">(.*)<\/div>/isU", '', $tmpInfo);