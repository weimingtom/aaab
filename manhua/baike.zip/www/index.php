<?php
define('GODHOUSE_INIT', true);
header('Content-Type: text/html; charset=gb2312');
//exit('huyao');
require 'function.php';

$fromURL = 'http://baike.baidu.com/';
$targetURL = 'http://www.thief.com/';

$requestURL = $_SERVER['REQUEST_URI'];
$pageType = 'index';						// Ĭ�ϴ򿪵�ҳ��
if($requestURL == '/') {
	$requestURL = $fromURL;
} elseif(strpos($requestURL, '$$$') !== false) {
	$r = explode('$$$', $requestURL);
	$requestURL = sid_decode($r[1]).$r[0];
	if(strpos($r[0], '/') !== false) {
		$pageType = substr($r[0], 0, strpos($r[0], '/'));
	} else {
		$pageType = $r[0];
	}
	unset($r);
} else {
	if(strpos($requestURL, '/', 1) !== false) {
		$pageType = substr($requestURL, 1, strpos($requestURL, '/', 1)-1);
	} else {
		$pageType = $requestURL;
	}
	$requestURL = $fromURL.substr($requestURL, 1);
}

$curl = curl_init(); 
curl_setopt($curl, CURLOPT_URL, $requestURL);        
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
curl_setopt($curl, CURLOPT_TIMEOUT, 30);
curl_setopt($curl, CURLOPT_HEADER, 0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$tmpInfo = curl_exec($curl);  
curl_close($curl);

/* �滻title */
require 'replace.php';

/* href */
$tpl = array();
preg_match_all("/<a([^>]*)href=\"([^>]*)\"/is", $tmpInfo, $tpl);
$urlArr = $tpl[2];
$newUrlArr = array();
foreach($urlArr as $v) {
	if(strpos(strtolower($v), 'http://')!==false) {
		$position = strpos($v, '/', 8);
		if($position !== false) {
			$domain = substr($v, 0, $position+1);
			if($domain != $fromURL) {
				$lastUrl = substr($v, 0, $position);
				$firstUrl = $targetURL.substr($v, $position+1);
				if(strpos($firstUrl, '?') !== false) {
					$newUrlArr[] = $firstUrl.'$$$'.sid_encode($lastUrl);
				} else {
					$newUrlArr[] = $firstUrl.'?$$$'.sid_encode($lastUrl);
				}
			} else {
				$newUrlArr[] = str_replace($fromURL, $targetURL, $v);
			}
		} else {
			$newUrlArr[] = $targetURL;
		}
	} else{
		if($v == '/') {
			$newUrlArr[] = $targetURL;
		} elseif($v && $v{0}=='/') {
			$newUrlArr[] = $targetURL.substr($v, 1);
		} else {
			$newUrlArr[] = $targetURL;
		}
	}
} 

$tmpInfo = str_replace(replaceHref($urlArr), replaceHref($newUrlArr), $tmpInfo);
unset($tpl);

/* src */
$tpl = array();
preg_match_all("/<img([^>]*)src=\"([^\"]*?)\"([^>]*?)>/isU", $tmpInfo, $tpl);
$srcArr = $tpl[2];
$newSrcArr = array();
foreach($srcArr as $v) {
	$newSrcArr[] = $targetURL.'image.php?url='.sid_encode($v);
}
$tmpInfo = str_replace($tpl[0], replaceSrc($tpl[1], $newSrcArr, $tpl[3]), $tmpInfo);
//print_r($newSrcArr);
echo $tmpInfo;